# Yogesh Gupta - Portfolio Website

Fully responsive React multi-page portfolio for [yogeshwebdeveloper.com](https://yogeshwebdeveloper.com).

## Tech Stack

- React 19 + Vite + React Router
- Tailwind CSS v4
- Responsive design (mobile, tablet, desktop)

## Pages

| Page | Route |
|------|-------|
| Home | `/` |
| About Me | `/about` |
| Services | `/services` |
| My Work | `/work` |
| Testimonials | `/testimonials` |
| Blog | `/blog` |
| Contact | `/contact` |

## Getting Started

```bash
cd yogesh-portfolio
npm install
npm run dev
```

Open [http://localhost:5173/comapre-Plugin/](http://localhost:5173/comapre-Plugin/)

## Build

```bash
npm run build
npm run preview
```

## Structure

```
src/
├── components/     # Header, Footer, Layout, PageBanner
├── pages/          # All page components
├── data/           # Static content (later → WordPress API)
└── App.jsx         # React Router setup
```

## Next Steps

- WordPress headless CMS integration (dynamic content)
- Blog single post pages
- Project detail pages
